class EndPoints {
  static String baseUrl = "http://192.168.1.2:8000";

  static void setBaseUrl(String newBaseUrl) {
    baseUrl = newBaseUrl;
  }

  static const String similarityClusters = '/similarity/clusters';
}

class ApiKey {
  static String accept = "Accept";
  static String authorization = "Authorization";
  static String acceptLanguage = "Accept-Language";
  static String errorMessage = "message";
  static const String deviceIdentifier = 'device-identifier';
}
