part of 'device_identifier_bloc.dart';

@immutable
sealed class DeviceIdentifierState {}

final class DeviceIdentifierInitial extends DeviceIdentifierState {}

final class DeviceIdentifierInitialized extends DeviceIdentifierState {
  final String deviceIdentifier;

  DeviceIdentifierInitialized({required this.deviceIdentifier});
}
