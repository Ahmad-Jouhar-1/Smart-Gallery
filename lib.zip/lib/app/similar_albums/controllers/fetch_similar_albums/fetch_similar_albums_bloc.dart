import 'package:dio/dio.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:smart_gallery/app/similar_albums/models/similar_album_model.dart';
import 'package:smart_gallery/core/api/dio_consumer.dart';
import 'package:smart_gallery/core/api/end_points.dart';

part 'fetch_similar_albums_event.dart';
part 'fetch_similar_albums_state.dart';

class FetchSimilarAlbumsBloc
    extends Bloc<FetchSimilarAlbumsEvent, FetchSimilarAlbumsState> {
  DioConsumer api = DioConsumer(dio: Dio());

  FetchSimilarAlbumsBloc() : super(FetchSimilarAlbumsLoading()) {
    on<FetchSimilarAlbums>((event, emit) async {
      emit(FetchSimilarAlbumsLoading());

      try {
        final response = await api.get(EndPoints.similarityClusters);

        final List<SimilarAlbumModel> similarAlbums =
            (response as List<dynamic>)
                .map((similarAlbum) => SimilarAlbumModel.fromJson(similarAlbum))
                .toList();

        if (similarAlbums.isEmpty) {
          emit(FetchSimilarAlbumsLoadedEmpty());
        } else {
          emit(FetchSimilarAlbumsLoaded(similarAlbum: similarAlbums));
        }
      } on Error catch (e) {
        emit(FetchSimilarAlbumsFailed(errorMessage: e.toString()));
      }
    });

    on<RenameSimilarAlbum>((event, emit) {
      _allSimilarAlbums =
          _allSimilarAlbums
              .map(
                (album) =>
                    album.id == event.id
                        ? album.copyWith(name: event.newName)
                        : album,
              )
              .toList();

      _emitLoaded(emit);
    });
  }

  List<SimilarAlbumModel> _allSimilarAlbums = [];

  void _emitLoaded(Emitter<FetchSimilarAlbumsState> emit) {
    if (_allSimilarAlbums.isEmpty) {
      emit(FetchSimilarAlbumsLoadedEmpty());
    } else {
      emit(FetchSimilarAlbumsLoaded(similarAlbum: _allSimilarAlbums));
    }
  }
}
