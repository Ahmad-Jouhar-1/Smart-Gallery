class EndPoints {
  static String baseUrl = "http://192.168.1.2:8000";

  static void setBaseUrl(String newBaseUrl) {
    baseUrl = newBaseUrl;
  }

  static const String similarityClusters = '/similarity/clusters';

  static String cluster(int clusterId) {
    return '$similarityClusters/$clusterId';
  }
}

class ApiKey {
  static String accept = "Accept";
  static String authorization = "Authorization";
  static String acceptLanguage = "Accept-Language";
  static String errorMessage = "message";
  static const String deviceIdentifier = 'device-identifier';
  static const String detail = 'detail';
  static const String validationMessage = 'msg';
  static const String bestPhoto = 'best_photo';
  static const String allPhotos = 'all_photos';
  static const String id = 'id';
  static const String image = 'image';
  static const String rate = 'rate';
  static const String isSelected = 'is_selected';
}
