import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_gallery/app/people_albums/controllers/fetch_person_albums/fetch_person_albums_bloc.dart';
import 'package:smart_gallery/app/people_albums/view/widgets/person_albums_failed_widget.dart';
import 'package:smart_gallery/app/people_albums/view/widgets/person_albums_loaded_empty_widget.dart';
import 'package:smart_gallery/app/people_albums/view/widgets/person_albums_loaded_widget.dart';
import 'package:smart_gallery/core/constants/app_colors.dart';
import 'package:smart_gallery/core/controllers/selection/selection_bloc.dart';
import 'package:smart_gallery/core/services/media_share_service.dart';
import 'package:smart_gallery/core/widgets/app_bar_widget.dart';
import 'package:smart_gallery/core/widgets/loading_widget.dart';
import 'package:smart_gallery/core/widgets/share_bar_widget.dart';
import 'package:smart_gallery/core/widgets/share_options_sheet_widget.dart';

class PeopleAlbumsScreen extends StatelessWidget {
  const PeopleAlbumsScreen({super.key});

  Future<void> _onRefresh(BuildContext context) async {
    context.read<FetchPersonAlbumsBloc>().add(FetchPersonAlbums());
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => FetchPersonAlbumsBloc()..add(FetchPersonAlbums()),
        ),
        BlocProvider(create: (context) => SelectionBloc()),
      ],
      child: Scaffold(
        backgroundColor: AppColors.primaryBackgroundColor,
        appBar: AppBarWidget(
          title: "AI Gallery",
          subtitle: "People",
          icon: Icons.filter_alt_outlined,
          onTap: () {},
        ),
        body: Builder(
          builder: (context) {
            return RefreshIndicator(
              onRefresh: () => _onRefresh(context),
              color: AppColors.primaryColor,
              backgroundColor: AppColors.accentBackgroundColor,
              child: BlocBuilder<FetchPersonAlbumsBloc, FetchPersonAlbumsState>(
                builder: (context, state) {
                  switch (state) {
                    case FetchPersonAlbumsLoading():
                      return LoadingWidget();
                    case FetchPersonAlbumsLoaded():
                      return BlocBuilder<SelectionBloc, SelectionState>(
                        builder: (context, selectionState) {
                          return PersonAlbumsLoadedWidget(
                            personAlbums: state.personAlbums,
                            isSelecting: selectionState.isSelecting,
                            selectedIds: selectionState.selectedIds,
                            onStartSelecting: (id) => context
                                .read<SelectionBloc>()
                                .add(StartSelecting(id: id)),
                            onToggleSelected: (id) => context
                                .read<SelectionBloc>()
                                .add(ToggleSelected(id: id)),
                          );
                        },
                      );
                    case FetchPersonAlbumsLoadedEmpty():
                      return PersonAlbumsLoadedEmptyWidget(
                        image: "assets/images/similar_empty.png",
                        title: "No People Found",
                        subtitle:
                            "Capture new moments or upload your favourite images.",
                      );
                    case FetchPersonAlbumsFailed():
                      return PersonAlbumsFailedWidget(
                        image: "assets/images/similar_empty.png",
                        title: "Something Went Wrong",
                        subtitle:
                            "Oops! An unexpected error occurred. Please try again in a moment.",
                        onTryAgain: () {
                          _onRefresh(context);
                        },
                      );
                  }
                },
              ),
            );
          },
        ),
        bottomNavigationBar: BlocBuilder<SelectionBloc, SelectionState>(
          builder: (context, selectionState) {
            if (!selectionState.isSelecting) return const SizedBox.shrink();

            return ShareBarWidget(
              selectedCount: selectionState.selectedIds.length,
              onCancel: () => context.read<SelectionBloc>().add(ClearSelection()),
              onShare: () => _share(context, selectionState.selectedIds),
            );
          },
        ),
      ),
    );
  }

  void _share(BuildContext context, Set<int> selectedIds) {
    final state = context.read<FetchPersonAlbumsBloc>().state;
    if (state is! FetchPersonAlbumsLoaded) return;

    final selectedPersons = state.personAlbums
        .where((person) => selectedIds.contains(person.id))
        .toList();

    ShareOptionsSheetWidget.show(
      context,
      onPicked: () => MediaShareService.shareImages(
        selectedPersons.map((person) => person.image).toList(),
        text: selectedPersons.map((person) => person.name).join(', '),
      ),
    );
  }
}
