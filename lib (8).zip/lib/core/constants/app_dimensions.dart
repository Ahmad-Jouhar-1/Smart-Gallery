import 'package:smart_gallery/core/extentions/dimensions_extensions/percent_sized_extension.dart';
import 'package:smart_gallery/core/extentions/dimensions_extensions/responsive_text_extension.dart';

class AppDimensions {
  static double sp = 2.0.wp;
  static double mp = 4.0.wp;
  static double lp = 6.0.wp;
  static double xlp = 8.0.wp;

  static double sm = 2.0.wp;
  static double mm = 4.0.wp;
  static double lm = 6.0.wp;
  static double xlm = 8.0.wp;

  static double sbr = 12.0.sp;
  static double mbr = 15.0.sp;
  static double lbr = 999.0.sp;

  static double sfs = 10.0.sp;
  static double mfs = 12.0.sp;
  static double lfs = 14.0.sp;
  static double xlfs = 16.0.sp;

  static double sis = 6.0.wp;
  static double mis = 8.0.wp;
  static double lis = 10.0.wp;
}
