import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:meta/meta.dart';
import 'package:smart_gallery/core/errors/exceptions.dart';

part 'rename_person_event.dart';
part 'rename_person_state.dart';

class RenamePersonBloc extends Bloc<RenamePersonEvent, RenamePersonState> {
  RenamePersonBloc() : super(RenamePersonInitial()) {
    on<RenamePerson>((event, emit) async {
      final newName = event.newName.trim();

      if (newName.isEmpty) {
        emit(RenamePersonFailed(errorMessage: "Person name can't be empty."));
        return;
      }

      emit(RenamePersonLoading(personId: event.id));

      try {
        await Future.delayed(const Duration(milliseconds: 500));

        emit(RenamePersonLoaded(id: event.id, newName: newName));
      } on ServerException catch (e) {
        emit(RenamePersonFailed(errorMessage: e.errorModel.errorMessage));
      }
    });
  }
}
